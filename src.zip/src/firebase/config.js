// Import the functions you need from the SDKs you need
import {getAuth } from "firebase/auth"
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyAod5Y-crH_w4kwkfyGXDRBsAKWV80_ouE",
  authDomain: "pruebfirebase-80a02.firebaseapp.com",
  projectId: "pruebfirebase-80a02",
  storageBucket: "pruebfirebase-80a02.firebasestorage.app",
  messagingSenderId: "437289219569",
  appId: "1:437289219569:web:c54fa5f45f10bc20568050",
  measurementId: "G-3LL77RKVKV"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const auth = getAuth()

export { app, auth}