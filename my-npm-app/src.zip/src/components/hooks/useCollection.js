import { db } from "./config";
import { collection, addDoc, query, where, getDocs, orderBy } from 'firebase/firestore';
import { useState } from 'react';

const useCollection = (table) => {
    const [results, setResults] = useState([]);
    const [error, setError] = useState(null);
    const [isPending, setIsPending] = useState(false);

    const getAll = async (condition1, condition2, condition3) => {
        setIsPending(true);
        let reduce = [];
        let q = null;

        if (condition1 && condition1.length === 3) {
            q = query(collection(db, table), where(condition1[0], condition1[1], condition1[2]));
        } else {
            q = query(collection(db, table));
        }

        reduce = await getDocs(q);

        reduce.forEach((doc) => {
            setResults((list) => [...list, { ...doc.data(), id: doc.id }]);
        });

        setIsPending(false);
    };

    const add = async (doc) => {
        setError(null);
        setIsPending(true);

        try {
            const reduce = await addDoc(collection(db, table), doc);
            setResults((list) => [...list, { ...doc, id: reduce.id }]);
            return reduce.id;
        } catch (err) {
            console.log(err.message);
            setError('Could not send the message');
            setIsPending(false);
            return null;
        }
    };

    return { error, isPending, results, add, getAll };
};

export default useCollection;
